# Streamlit A/B Test Evaluation

App to test the significance of the results from A/B Tests that we run at work.

Install the packages from `requirements.txt`

Run the app with `streamlit run app.py`
